import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private https:HttpClient) { }

  user_login(username:string,password:string):Observable<any>{
    return this.https.post("/user/login", {username,password})
  }

  user_register(username:string,password:string):Observable<any>{
    return this.https.post("/user/register", {username,password})
  }
}
