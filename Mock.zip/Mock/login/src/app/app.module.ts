import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from "@angular/core";
import { LoginRegisterComponent } from "./login-register/login-register.component";
import { AppComponent } from "./app.component";
import { AuthenticationService } from "./authentication.service";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from "./app-routing.module";
import { BrowserModule } from "@angular/platform-browser";

@NgModule({
    declarations: [LoginRegisterComponent, AppComponent],
    providers: [AuthenticationService],
    exports: [LoginRegisterComponent, AppComponent],
    bootstrap: [AppComponent],
    imports: [FormsModule, ReactiveFormsModule, BrowserModule, LoginRegisterComponent, HttpClientModule, AppRoutingModule], schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }