import { RouterModule, Routes } from "@angular/router";
import { LoginRegisterComponent } from "./login-register/login-register.component";
import { NgModule } from "@angular/core";

const routes : Routes = [{
    path:'login-register',
    component: LoginRegisterComponent
}];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {} 