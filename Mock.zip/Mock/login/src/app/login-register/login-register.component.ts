import { Component } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { error } from 'console';
import { catchError } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login-register',
  standalone: true,
  imports: [LoginRegisterComponent, CommonModule, FormsModule],
  templateUrl: './login-register.component.html',
  styleUrl: './login-register.component.css'
})
export class LoginRegisterComponent {
  newUser:boolean=false;
  oldUser:boolean=true;
  username:string="";
  password:string="";
  loginFailed:boolean=false;
  newUsername:string="";
  newPassword:string="";
  registrationError:string="";

  constructor(private authService:AuthenticationService) { }

  login(){
    console.log("loginnnnn")
    this.authService.user_login(this.username,this.password).pipe(
      catchError(error =>{
        this.loginFailed=true;
        console.error("Login Failed:", error)
        throw error;
      })
    )
    .subscribe(response =>{
      let val = response.data;
      if(val["is_uservalid"]){
      console.log("Login Successful")
      }
    })
  }

  register(){
    this.authService.user_register(this.newUsername,this.newPassword).pipe(
      catchError(error =>{
        this.registrationError="Registration Failed";
        console.error("Registration Failed:", error)
        throw error;
      })
    )
    .subscribe(response =>{
      let val = response.data;
      if(val["is_useradded"]){
        console.log("Registration Successful")
      }
      
    })
  }

  toggleUser(){
    console.log("New User")
    this.newUser=true;
    this.oldUser=false;
  }

}

